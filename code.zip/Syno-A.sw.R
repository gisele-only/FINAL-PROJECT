rm(list=ls())
library(lme4)
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tidyverse)
library(gridExtra)
library(cowplot)

setwd("D:/ic/Fe")

d.S<-read_excel("RFUSynoA.sw.xlsx")

# 分别绘制400nm、160nm、16nm、1.6nm的图不同温度
plots.S <- list()

concentrations <- c("2290pM", "916pM", "91.6pM", "9.16pM")

colors <- c("17°C" = "#EDB8B0", "20°C" = "#F54D40", "23°C" = "#941B14")

global_y_min <- min(d.S$RFU, na.rm = TRUE)
global_y_max <- max(d.S$RFU, na.rm = TRUE) 
# 计算y轴的全局范围
for (i in 1:length(concentrations)) {
  conc <- concentrations[i]
  d.S1 <- subset(d.S, concentration == conc)
  
  y_min <- global_y_min
  y_max <- global_y_max
  
  x_breaks <- unique(d.S1$days)
  
  p.S <- ggplot(d.S1, aes(x = days, y = RFU, color = temperature, group = temperature)) +
    geom_point(size = 4, shape = 16) +
    geom_line(linetype = "dashed") +
    scale_color_manual(values = colors) +
    scale_y_continuous(limits = c(y_min, y_max), labels = scales::comma) +
    scale_x_continuous(breaks = seq(min(d.S1$days), max(d.S1$days), by = 1)) + # 精确控制间隔
    labs(title = conc, x = "Days", y = "RFU") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, margin = margin(t = 10)),
      plot.title = element_text(hjust = 0.5, size = 12),
      legend.position = "none",
      axis.text.y = element_text(color = if(i > 1) "transparent" else "black"),  # Hide y-axis text for all but the first plot
      axis.ticks.y = element_line(color = if(i > 1) "transparent" else "black"),  # Hide y-axis ticks for all but the first plot
      axis.title.y = element_blank()
    )
  
  plots.S[[i]] <- p.S
}

# 创建一个图例
legend_plot.S <- ggplot(d.S, aes(x = days, y = RFU, color = temperature)) +
  geom_point(size = 4, shape = 16) +
  scale_color_manual(values = colors) +
  guides(color = guide_legend(title = "Temperature")) +
  theme_minimal() +
  theme(legend.position = "right") # 竖直放置图例

legend.S <- cowplot::get_legend(legend_plot.S)

# 调整最下面的图形的空间分配
rel_heights_values <- c(rep(1, length(concentrations) - 1), 1.5, 0.1)  # 给最后一个图更多的空间

# 组合图形与图例
final_plot.S <- plot_grid(plotlist = plots.S, align = 'v', nrow = 1, rel_heights = rel_heights_values)
combined_plot <- plot_grid(final_plot.S, legend.S, ncol = 2, rel_widths = c(1, 0.1))

# 添加标题
y_label.S <- grid::textGrob("RFU", rot = 90, gp = grid::gpar(fontsize = 14, fontface = "bold"))

# 绘制最终图形
p.S.RFU<-grid.arrange(arrangeGrob(combined_plot, left = y_label.S))

# 保存图形为高分辨率JPG格式
ggsave("Syno Warming on Growth.jpg", plot = p.S.RFU, width = 15, height = 7, dpi = 300)
###########################


# 画图-生长速率常数-温度
d.s <- read_excel("lnRFUSynoA.sw.xlsx")

# 对每组数据进行线性回归并计算生长速率常数

growth_rates.s <- d.s %>%
  group_by(temperature, concentration) %>%
  summarize(
    growth_rate_constant.s = coef(lm(RFU ~ days))[2],
    growth_rate_se = summary(lm(RFU ~ days))$coefficients[2, "Std. Error"]
  ) %>%
  ungroup()

# 将 concentration 列转换为因子，并按数值顺序排序
growth_rates.s <- growth_rates.s %>%
  mutate(concentration = factor(concentration, levels = c(c("2290pM","916pM","91.6pM","9.16pM")))) %>%
  arrange(concentration)

# 查看结果
print(growth_rates.s)

# 保存到新的数据框

growth_rates_df.S <- as.data.frame(growth_rates.s)

# 画图-生长速率常数-铁浓度

custom_colors.Fe <- c("17°C" = "#EDB8B0", "20°C" = "#F54D40", "23°C" = "#941B14")

# 绘制柱状图
p.S.GR.Fe <- ggplot(growth_rates_df.S, aes(x = concentration, y = growth_rate_constant.s, fill = temperature)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.6) +  # 调整柱子的宽度
  geom_errorbar(aes(ymin = growth_rate_constant.s - growth_rate_se, ymax = growth_rate_constant.s + growth_rate_se),
                position = position_dodge(width = 0.8), width = 0.25) +  
  labs(
    x = "Iron Concentration (pM)",
    y = "Growth Rate (1/day)",
    fill = "Temperature"
  ) +
  theme_minimal() +
  theme(
    axis.title = element_text(size = 14, face = "bold"),
    axis.text = element_text(size = 12),
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.position = "right"
  ) +
  scale_fill_manual(values = custom_colors.Fe)  # 使用自定义颜色

# 显示图形
print(p.S.GR.Fe)

# 保存图形为高分辨率JPG格式
ggsave("Growth Rate Constants Syno Temperature.jpg", plot = p.S.GR.Fe, width = 10, height = 6, dpi = 300)

#输出为生长速率常数表格
library(writexl)

# 将数据框保存为 Excel 文件
write_xlsx(growth_rates_df.S, "growth_rates_df.S.xlsx")

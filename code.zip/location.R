
rm(list=ls())
library(ggplot2)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)
library(maps)


# 设置坐标
coordinates <- data.frame(
  lon = -168,
  lat = 26 + 10/60 + 5/3600
)

# 将坐标转换为 sf 对象
coordinates_sf <- st_as_sf(coordinates, coords = c("lon", "lat"), crs = 4326)

# 获取世界地图数据
world <- ne_countries(scale = "medium", returnclass = "sf")

# 绘制地图，设置海洋和陆地颜色，并标注大陆名称
map_plot <- ggplot(data = world) +
  geom_sf(fill = "grey", color = "black") +  # 陆地颜色为浅灰色，边界为黑色
  geom_point(data = coordinates, aes(x = lon, y = lat), color = "red", size = 4, shape = 16) +  # 使用红色五角星标记
  coord_sf(xlim = c(-180, -80), ylim = c(10, 60), expand = FALSE) +
  theme_minimal() +
  annotation_scale(location = "bl", width_hint = 0.5) +
  annotation_north_arrow(location = "bl", which_north = "true", 
                         pad_x = unit(0.75, "in"), pad_y = unit(0.5, "in"),
                         style = north_arrow_fancy_orienteering) +
  labs(
       x = "Longitude",
       y = "Latitude") +
  theme_minimal() +
  theme(plot.title = element_text(size = 18, face = "bold"),
        plot.subtitle = element_text(size = 14)) +
  annotate("text", x = -100, y = 40, label = "Asia", color = "black", size = 5)

map_plot
# 保存地图为PNG文件
ggsave("4.jpg", plot = map_plot, dpi = 300, width = 12, height = 8)

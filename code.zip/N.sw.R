rm(list=ls())
library(lme4)
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tidyverse)
library(gridExtra)
library(cowplot)

setwd("D:/ic/Fe")

# E.hux人工海水图
d.E <- read_excel("E.huxN.sw.xlsx")

colors <- c("17°C" = "#EDB8B0", "20°C" = "#F54D40", "23°C" = "#941B14")

# 定义颜色

plot <- ggplot(d.E, aes(x = days, y = RFU, color = temperature, group = temperature)) +
  geom_line(linetype = "dashed") +
  geom_point(size = 4) +
  labs(x = "Days", y = "RFU") +
  scale_color_manual( values = colors) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 22, face = "bold"),
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 10),
    legend.position = "right")
  
plot
ggsave("E.hux N.sw.jpg", plot = plot, width = 10, height = 6, dpi = 300)
# Print the plot
print(plot)

################################
d.E1 <- read_excel("RFUE.huxN.sw.xlsx")
d.E2 <- read_excel("E.huxN.sw2.xlsx")

# 添加一个新的列来标识实验来源
d.E1$experiment <- "Experiment 1"
d.E2$experiment <- "Experiment 2"

# 合并两个数据框
d_E <- bind_rows(d.E1, d.E2)

model.E <- lm(RFU ~ temperature + days, data = d_E)
summary(model.E)
####################################
d.P <- read_excel("P.tricoN.sw.xlsx")

colors <- c("17°C" = "#EDB8B0", "20°C" = "#F54D40", "23°C" = "#941B14")

# 定义颜色

plot <- ggplot(d.P, aes(x = days, y = RFU, color = temperature, group = temperature)) +
  geom_line(linetype = "dashed") +
  geom_point(size = 4) +
  labs(x = "Days", y = "RFU") +
  scale_color_manual( values = colors) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 22, face = "bold"),
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 10),
    legend.position = "right")

plot
ggsave("P.trico N.sw.jpg", plot = plot, width = 10, height = 6, dpi = 300)
# Print the plot
print(plot)

################################
d.P2 <- read_excel("P.tricoN.sw2.xlsx")
d.P3 <- read_excel("P.tricoN.sw3.xlsx")
# 添加一个新的列来标识实验来源
d.P2$experiment <- "Experiment 2"
d.P3$experiment <- "Experiment 3"

# 合并两个数据框
d_P <- bind_rows(d.P2, d.P3)


model.P <- lm(RFU ~ temperature + days, data = d_P)
summary(model.P)

######################################
d.T <- read_excel("T.wN.sw.xlsx")

colors <- c("17°C" = "#EDB8B0", "20°C" = "#F54D40", "23°C" = "#941B14")

# 定义颜色

plot <- ggplot(d.T, aes(x = days, y = RFU, color = temperature, group = temperature)) +
  geom_line(linetype = "dashed") +
  geom_point(size = 4) +
  labs( x = "Days", y = "RFU") +
  scale_color_manual( values = colors) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 22, face = "bold"),
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 10),
    legend.position = "right")

ggsave("T.w N.sw.jpg", plot = plot, width = 10, height = 6, dpi = 300)
# Print the plot
print(plot)

################################
d.T1 <- read_excel("RFUT.wN.sw.xlsx")
d.T2 <- read_excel("T.wN.sw2.xlsx")

# 添加一个新的列来标识实验来源
d.T1$experiment <- "Experiment 1"
d.T2$experiment <- "Experiment 2"


# 合并两个数据框
d_T <- bind_rows(d.T1, d.T2)


model.T <- lm(RFU ~ temperature + days, data = d.T2)
summary(model.T)
############################################################
d.S <- read_excel("SynoN.sw.xlsx")

# 定义颜色

plot <- ggplot(d.S, aes(x = days, y = RFU, color = temperature, group = temperature)) +
  geom_line(linetype = "dashed") +
  geom_point(size = 4) +
  labs(x = "Days", y = "RFU") +
  scale_color_manual(values = colors) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 22, face = "bold"),
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 10),
    legend.position = "right")

ggsave("SynoN.sw.jpg", plot = plot, width = 10, height = 6, dpi = 300)
# Print the plot
print(plot)

################################

model.S <- lm(rfu ~ temperature + days, data = d.S)
summary(model.S)

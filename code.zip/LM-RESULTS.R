rm(list=ls())

library(lme4)
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tidyverse)

setwd("D:/ic/Fe")

d.E<-read_excel("lnRFU-E.hux.xlsx")

d.E$concentration <- factor(d.E$concentration, levels = c("9.16pM", "91.6pM", "916pM", "2290pM"))
d.E$temperature <- factor(d.E$temperature)

#温度影响
results <- list()
concentrations <- levels(d.E$concentration)

# 按铁浓度分组建模
for (conc in concentrations) {
  subset_data <- d.E %>% filter(concentration == conc)
  model <- lm(RFU ~ temperature + DAY, data = subset_data)
  results[[conc]] <- summary(model)
}

# 打印每个铁浓度下的模型摘要
for (conc in concentrations) {
  cat("\nConcentration:", conc, "\n")
  print(results[[conc]])
}

#####################################
#P.trico
d.P<-read_excel("lnRFU-P.trico.xlsx")

d.P$concentration <- factor(d.P$concentration, levels = c("9.16pM", "91.6pM", "916pM", "2290pM"))
d.P$temperature <- factor(d.P$temperature)

#温度影响
results <- list()
concentrations <- levels(d.P$concentration)

# 按铁浓度分组建模
for (conc in concentrations) {
  subset_data <- d.P %>% filter(concentration == conc)
  model <- lm(RFU ~ temperature + days, data = subset_data)
  results[[conc]] <- summary(model)
}

# 打印每个铁浓度下的模型摘要
for (conc in concentrations) {
  cat("\nConcentration:", conc, "\n")
  print(results[[conc]])
}


############################################
d.T<-read_excel("lnRFUT.wA.sw.xlsx")

d.T$concentration <- factor(d.T$concentration, levels = c("9.16pM", "91.6pM", "916pM", "2290pM"))
d.T$temperature <- factor(d.T$temperature)

#温度影响
results <- list()
concentrations <- levels(d.T$concentration)

# 按铁浓度分组建模
for (conc in concentrations) {
  subset_data <- d.T %>% filter(concentration == conc)
  model <- lm(RFU ~ temperature + days, data = subset_data)
  results[[conc]] <- summary(model)
}

# 打印每个铁浓度下的模型摘要
for (conc in concentrations) {
  cat("\nConcentration:", conc, "\n")
  print(results[[conc]])
}


############################################################3
d.S<-read_excel("lnRFUSynoA.sw.xlsx")

d.S$concentration <- factor(d.S$concentration, levels = c("9.16pM", "91.6pM", "916pM", "2290pM"))
d.S$temperature <- factor(d.S$temperature)

#温度影响
results <- list()
concentrations <- levels(d.S$concentration)

# 按铁浓度分组建模
for (conc in concentrations) {
  subset_data <- d.S %>% filter(concentration == conc)
  model <- lm(RFU ~ temperature + days, data = subset_data)
  results[[conc]] <- summary(model)
}

# 打印每个铁浓度下的模型摘要
for (conc in concentrations) {
  cat("\nConcentration:", conc, "\n")
  print(results[[conc]])
}


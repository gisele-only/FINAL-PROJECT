rm(list=ls())
library(ggplot2)
library(cowplot)
library(magick)
library(grid)


setwd("D:/ic/Fe")
e1 <- magick::image_read("Growth Rate Constants E.hux Temperature.jpg")
e2 <- magick::image_read("E.hux Warming on Growth.jpg")
p1 <- magick::image_read("Growth Rate Constants P.trico Temperature.jpg")
p2 <- magick::image_read("P.trico Warming on Growth.jpg")
t1 <- magick::image_read("Growth Rate Constants T.w Temperature.jpg")
t2 <- magick::image_read("T.w Warming on Growth.jpg")
s1 <- magick::image_read("Growth Rate Constants Syno Temperature.jpg")
s2 <- magick::image_read("Syno Warming on Growth.jpg")
E1 <- magick::image_read("E.hux N.sw.jpg")
P1 <- magick::image_read("P.trico N.sw.jpg")
T1 <- magick::image_read("T.w N.sw.jpg")
S1 <- magick::image_read("SynoN.sw.jpg")


plot1 <- ggplot() + 
  annotation_custom(rasterGrob(e1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot2 <- ggplot() + 
  annotation_custom(rasterGrob(e2, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(
    panel.border = element_rect(colour = "black", fill = NA, size = 1),  # 添加黑色边框
    plot.margin = unit(c(1, 1, 1, 1), "cm")  # 设置图形内容与边框之间的距离
  )

plot2

plot3 <- ggplot() + 
  annotation_custom(rasterGrob(p1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot4 <- ggplot() + 
  annotation_custom(rasterGrob(p2, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot5 <- ggplot() + 
  annotation_custom(rasterGrob(t1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot6 <- ggplot() + 
  annotation_custom(rasterGrob(t2, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot7 <- ggplot() + 
  annotation_custom(rasterGrob(s1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot8 <- ggplot() + 
  annotation_custom(rasterGrob(s2, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot9 <- ggplot() + 
  annotation_custom(rasterGrob(E1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot10 <- ggplot() + 
  annotation_custom(rasterGrob(P1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot11 <- ggplot() + 
  annotation_custom(rasterGrob(T1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1))  # 添加黑色边框

plot12 <- ggplot() + 
  annotation_custom(rasterGrob(S1, width=unit(1,"npc"), height=unit(1,"npc"))) + 
  theme_void() +
  theme(plot.margin = unit(c(1,1,1,1), "cm"),  # 设置边距
        panel.border = element_rect(colour = "black", fill=NA, size=1)) 


final_plot <- plot_grid(plot2, plot4, plot6, plot8, nrow = 2, labels = "AUTO")
final_plot2 <- plot_grid(plot1, plot3, plot5, plot7, nrow = 2,labels = "AUTO")
final_plot3 <- plot_grid(plot9, plot10, plot11, plot12, ncol = 2, labels = "AUTO")
final_plot4 <- plot_grid(plot7, plot8, ncol = 1, labels = "AUTO")
final_plot5 <- plot_grid(plot9, plot10, ncol = 1,labels = "AUTO")
final_plot6 <- plot_grid(plot11, plot12, ncol = 1, labels = "AUTO")



print(final_plot)


ggsave("1.jpg", plot = final_plot, width = 12, height = 8, dpi = 300)
ggsave("2.jpg", plot = final_plot2, width = 12, height = 8, dpi = 300)
ggsave("3.jpg", plot = final_plot3, width = 12, height = 8, dpi = 300)

